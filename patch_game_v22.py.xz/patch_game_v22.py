from pathlib import Path
import re

ROOT = Path('NeonShooter')
GAME = ROOT / 'app/src/main/java/com/claude/neonshooter/GameView.kt'
ACTIVITY = ROOT / 'app/src/main/java/com/claude/neonshooter/MainActivity.kt'
GRADLE = ROOT / 'app/build.gradle.kts'
STRINGS = ROOT / 'app/src/main/res/values/strings.xml'

g = GAME.read_text(encoding='utf-8')

def rep(old: str, new: str, label: str, count: int = 1):
    global g
    found = g.count(old)
    if found < count:
        raise SystemExit(f'Patch anchor missing ({label}): expected {count}, got {found}')
    g = g.replace(old, new, count)

# Text shaping: Canvas.drawText does not shape Arabic/Persian glyphs. StaticLayout does.
rep('import android.app.Activity\n', 'import android.app.Activity\nimport android.text.Layout\nimport android.text.StaticLayout\nimport android.text.TextDirectionHeuristics\nimport android.text.TextPaint\n', 'Persian text imports')
rep('private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) }',
    'private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create("sans-serif", Typeface.BOLD) }', 'Persian text paint')
rep('''    private fun text(c: Canvas, t: String, x: Float, y: Float, size: Float, color: Int, align: Paint.Align = Paint.Align.CENTER) {
        tp.textSize = size * s; tp.color = color; tp.textAlign = align
        c.drawText(t, x * s, y * s, tp)
    }''', '''    private fun text(c: Canvas, t: String, x: Float, y: Float, size: Float, color: Int, align: Paint.Align = Paint.Align.CENTER) {
        tp.textSize = size * s
        tp.color = color
        val isPersian = t.any { it in '\\u0600'..'\\u06FF' || it in '\\uFB50'..'\\uFDFF' || it in '\\uFE70'..'\\uFEFF' }
        if (!isPersian) {
            tp.textAlign = align
            c.drawText(t, x * s, y * s, tp)
            return
        }
        val width = (tp.measureText(t) * 1.22f + 10f * s).roundToInt().coerceIn(1, max(1, sw))
        val layout = StaticLayout.Builder.obtain(t, 0, t.length, tp, width)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .setIncludePad(false)
            .build()
        val left = when (align) {
            Paint.Align.LEFT -> x * s
            Paint.Align.RIGHT -> x * s - width
            else -> x * s - width / 2f
        }
        c.save()
        c.translate(left, y * s - layout.getLineBaseline(0))
        layout.draw(c)
        c.restore()
    }''', 'Persian text renderer')

# Aim for 90Hz where the display supports it, without forcing devices capped at 60Hz.
rep('''    override fun run() {
        var last = System.nanoTime()
        while (running) {
            val now = System.nanoTime()
            val dt = min(0.033f, (now - last) / 1e9f); last = now''', '''    override fun run() {
        val targetFrameNanos = 1_000_000_000L / 90L
        var last = System.nanoTime()
        while (running) {
            val frameStart = System.nanoTime()
            val dt = min(0.05f, (frameStart - last) / 1e9f); last = frameStart''', '90 FPS frame loop')
rep('''            try { Thread.sleep(8) } catch (e: InterruptedException) {}
        }
    }''', '''            val remaining = targetFrameNanos - (System.nanoTime() - frameStart)
            if (remaining > 0L) {
                try { Thread.sleep(remaining / 1_000_000L, (remaining % 1_000_000L).toInt()) }
                catch (e: InterruptedException) { if (!running) break }
            } else Thread.yield()
        }
    }''', '90 FPS frame pacing')

# Slow star drift makes the ship feel like it is moving forward.
rep('''        val dt = frameDt * 0.85f
        for (star in stars) star.phase += dt * (2.4f + star.sp * 0.16f)
        cometSpawnTimer -= dt
        if (cometSpawnTimer <= 0f) {
            val speed = 27f + Random.nextFloat() * 10f
            comets.add(Comet(Random.nextFloat() * W, -3f, (Random.nextFloat() - 0.5f) * 3f, speed, 5f + Random.nextFloat() * 2f, 6.5f, 6.5f))
            cometSpawnTimer = 7f + Random.nextFloat() * 8f
        }
        for (comet in comets) {
            comet.x += comet.vx * dt
            comet.y += comet.vy * dt
            comet.life -= dt
        }
        comets.removeAll { it.life <= 0f || it.y > wh + 12f }''', '''        val dt = frameDt * 0.85f
        for (star in stars) {
            star.phase += dt * (2.4f + star.sp * 0.16f)
            star.y += (3.5f + star.sp * 0.28f) * dt
            if (star.y > wh + 2f) {
                star.y = -2f
                star.x = Random.nextFloat() * W
            }
        }
        cometSpawnTimer -= dt
        if (cometSpawnTimer <= 0f) {
            val speed = 30f + Random.nextFloat() * 18f
            val edge = Random.nextInt(4)
            val startX: Float
            val startY: Float
            val targetX: Float
            val targetY: Float
            when (edge) {
                0 -> { startX = Random.nextFloat() * W; startY = -10f; targetX = Random.nextFloat() * W; targetY = wh + 10f }
                1 -> { startX = Random.nextFloat() * W; startY = wh + 10f; targetX = Random.nextFloat() * W; targetY = -10f }
                2 -> { startX = -10f; startY = Random.nextFloat() * wh; targetX = W + 10f; targetY = Random.nextFloat() * wh }
                else -> { startX = W + 10f; startY = Random.nextFloat() * wh; targetX = -10f; targetY = Random.nextFloat() * wh }
            }
            val dx = targetX - startX
            val dy = targetY - startY
            val distance = max(1f, hypot(dx, dy))
            val vx = dx / distance * speed
            val vy = dy / distance * speed
            val life = (distance / speed + 0.8f).coerceIn(3.5f, 9f)
            comets.add(Comet(startX, startY, vx, vy, 7f + Random.nextFloat() * 7f, life, life))
            cometSpawnTimer = 4f + Random.nextFloat() * 7f
        }
        for (comet in comets) {
            comet.x += comet.vx * dt
            comet.y += comet.vy * dt
            comet.life -= dt
        }
        comets.removeAll { it.life <= 0f || it.x < -22f || it.x > W + 22f || it.y < -22f || it.y > wh + 22f }''', 'star drift and multi-direction comets')
rep('private class Comet(var x: Float, var y: Float, val vx: Float, val vy: Float, val length: Float, var life: Float, val maxLife: Float)',
     'private class Comet(var x: Float, var y: Float, var vx: Float, var vy: Float, val length: Float, var life: Float, val maxLife: Float)', 'mutable comet heading')
rep('''            val tailX = (comet.x - comet.vx * 0.08f) * s
            val tailY = (comet.y - comet.length) * s''', '''            val velocity = max(1f, hypot(comet.vx, comet.vy))
            val tailX = (comet.x - comet.vx / velocity * comet.length) * s
            val tailY = (comet.y - comet.vy / velocity * comet.length) * s''', 'comet trail follows direction')

# Make enemies progressively tougher after wave 10: more health, speed and attack tempo.
rep('''            val hp = when (type) { 1 -> 5 + wave / 8; 3 -> 4 + wave / 10; 4 -> 3 + wave / 12; 5 -> 5 + wave / 10; 6 -> 4 + wave / 10; else -> 2 + wave / 12 }
            if (enemies.size + pendingWaveEnemies.size < waveTarget) {
                pendingWaveEnemies.add(E(x, y, type, hp, x, amp, t0))
            }''', '''            val baseHp = when (type) { 1 -> 5 + wave / 8; 3 -> 4 + wave / 10; 4 -> 3 + wave / 12; 5 -> 5 + wave / 10; 6 -> 4 + wave / 10; else -> 2 + wave / 12 }
            val difficulty = if (wave >= 10) 1.25f + min(wave - 10, 25) * 0.018f else 1f
            val hp = ceil(baseHp * difficulty).toInt()
            if (enemies.size + pendingWaveEnemies.size < waveTarget) {
                pendingWaveEnemies.add(E(x, y, type, hp, x, amp, t0))
            }''', 'wave 10+ enemy health scaling')
rep('''        when (wave % 3) {
            0 -> for (i in 0 until n) { val col = i % 8; val row = i / 8; mk((col + 0.5f) * W / 8f, -10f - row * 26f, 0f, 0f) }
            1 -> for (i in 0 until n) mk(W / 2, -10f - i * 24f, 55f, i * 0.6f)
            else -> for (i in 0 until n) {
                val side = if (i % 2 == 0) 1 else -1; val k = (i + 1) / 2
                mk(W / 2 + side * k * 20f, -10f - k * 14f, 0f, 0f)
            }
        }''', '''        when (wave % 4) {
            0 -> for (i in 0 until n) { val col = i % 8; val row = i / 8; mk((col + 0.5f) * W / 8f, -10f - row * 26f, 0f, 0f) }
            1 -> for (i in 0 until n) mk(W / 2, -10f - i * 24f, 55f, i * 0.6f)
            2 -> for (i in 0 until n) {
                val side = if (i % 2 == 0) 1 else -1; val k = (i + 1) / 2
                mk(W / 2 + side * k * 20f, -10f - k * 14f, 0f, 0f)
            }
            else -> for (i in 0 until n) {
                val lane = i % 2
                val row = i / 2
                val x = if (lane == 0) 18f + row * 17f else W - 18f - row * 17f
                mk(x.coerceIn(10f, W - 10f), -12f - row * 22f, if (wave >= 10) 34f else 22f, row * 0.42f)
            }
        }''', 'four distinct enemy formations')
rep('''        if (wave % 5 == 0) {
            waveTarget = enemies.count { !it.dead } + 1 + if (eventKind == 5) 3 else 0
            enemies.add(E(W / 2, -20f, 2, 300 + wave * 44, W / 2, 0f, ((wave / 5 - 1).coerceIn(0, 9)).toFloat()).also { it.fire = 1.35f })''', '''        if (wave % 5 == 0) {
            waveTarget = enemies.count { !it.dead } + 1 + if (eventKind == 5) 3 else 0
            val bossBaseHp = 300 + wave * 44
            val bossHp = if (wave == 5) (bossBaseHp * 0.70f).roundToInt() else bossBaseHp
            enemies.add(E(W / 2, -20f, 2, bossHp, W / 2, 0f, ((wave / 5 - 1).coerceIn(0, 9)).toFloat()).also { it.fire = 1.35f })''', 'first boss 30 percent less health')
rep('val spd = min(18f + wave * 1.15f, 38f)', 'val spd = if (wave >= 10) min(38f + (wave - 10) * 0.35f, 50f) else min(18f + wave * 1.15f, 38f)', 'wave 10+ enemy speed scaling')

# Smarter movement: advanced enemies shift lanes, lead the ship, and use brief feints.
rep('''                } else {
                    val sway = max(e.amp, 10f + min(wave.toFloat(), 10f))
                    e.x = (e.bx + sin(e.age * 1.7f + e.t0) * sway).coerceIn(10f, W - 10f)
                }
            }
            e.fire -= enemyDt''', '''                } else {
                    val sway = max(e.amp, 10f + min(wave.toFloat(), 10f))
                    e.x = (e.bx + sin(e.age * 1.7f + e.t0) * sway).coerceIn(10f, W - 10f)
                }
                if (wave >= 10 && e.type != 5) {
                    val style = (e.type + wave + e.t0.toInt()).mod(3)
                    val targetX = (px + (px - e.bx) * 0.12f).coerceIn(10f, W - 10f)
                    when (style) {
                        0 -> e.x += (targetX - e.x).coerceIn(-42f * enemyDt, 42f * enemyDt)
                        1 -> e.x = (e.x + sin(e.age * 2.9f + e.t0) * (12f + min(wave - 10, 18) * 0.45f) * enemyDt).coerceIn(10f, W - 10f)
                        else -> if (e.y > 18f) e.x += (px + sin(e.age * 2.1f + e.t0) * 20f - e.x).coerceIn(-58f * enemyDt, 58f * enemyDt)
                    }
                }
            }
            e.fire -= enemyDt''', 'wave 10+ adaptive enemy movement')

# Request a 90Hz surface when the Android release/API level supports it.
rep('import android.view.SurfaceHolder\n', 'import android.view.SurfaceHolder\nimport android.view.Surface\nimport android.os.Build\n', '90Hz surface imports')
rep('''    override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {
        synchronized(lock) { if (w != sw || hh != sh || !::bPlayer.isInitialized) setup(w, hh) }''', '''    override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {
        if (Build.VERSION.SDK_INT >= 30) {
            try { h.surface.setFrameRate(90f, Surface.FRAME_RATE_COMPATIBILITY_DEFAULT) } catch (_: Exception) {}
        }
        synchronized(lock) { if (w != sw || hh != sh || !::bPlayer.isInitialized) setup(w, hh) }''', 'request 90Hz game surface')

# Smarter movement: advanced enemies use multiple pursuit and feint patterns instead of a fixed lane.
rep('''                    val base = atan2(dy.toDouble(), dx.toDouble()).toFloat()
                        val speed = 72f + min(wave.toFloat(), 45f) * 1.4f
                        when (e.type) {
                            1 -> for (i in -1..1) { val a = base + i * 0.15f; bullets.add(B(e.x, e.y + 7f, cos(a) * speed, sin(a) * speed, false)) }
                            3 -> for (i in -1..1) { val a = base + i * 0.23f; bullets.add(B(e.x, e.y + 7f, cos(a) * speed * 1.1f, sin(a) * speed * 1.1f, false)) }
                            4 -> for (i in -2..2) { val a = base + i * 0.12f; bullets.add(B(e.x, e.y + 7f, cos(a) * speed * 0.88f, sin(a) * speed * 0.88f, false)) }
                            6 -> for (i in -2..2) { val a = base + i * 0.24f; bullets.add(B(e.x, e.y + 7f, cos(a) * speed * 1.25f, sin(a) * speed * 1.25f, false)) }
                            else -> for (i in -1..1) { val a = base + i * 0.12f; bullets.add(B(e.x, e.y + 7f, cos(a) * speed, sin(a) * speed, false)) }
                        }''', '''                    val base = atan2(dy.toDouble(), dx.toDouble()).toFloat()
                    val speed = (72f + min(wave.toFloat(), 45f) * 1.4f) * if (wave >= 10) 1.16f else 1f
                    if (wave >= 10) {
                        when ((e.type + wave + (e.age * 0.7f).toInt()).mod(4)) {
                            0 -> for (i in -2..2) { val a = base + i * 0.19f; bullets.add(B(e.x, e.y + 7f, cos(a) * speed, sin(a) * speed, false)) }
                            1 -> for (i in -1..1) { val a = base + i * 0.28f; val v = speed * if (i == 0) 1.28f else 0.92f; bullets.add(B(e.x, e.y + 7f, cos(a) * v, sin(a) * v, false)) }
                            2 -> {
                                for (side in -1..1 step 2) { val a = base + side * 0.38f; bullets.add(B(e.x, e.y + 7f, cos(a) * speed * 1.12f, sin(a) * speed * 1.12f, false)) }
                                bullets.add(B(e.x, e.y + 7f, cos(base) * speed * 0.78f, sin(base) * speed * 0.78f, false))
                            }
                            else -> {
                                for (i in -2..2) { val a = base + i * 0.13f; val v = speed * if (e.type == 6) 1.25f else 0.88f; bullets.add(B(e.x, e.y + 7f, cos(a) * v, sin(a) * v, false)) }
                            }
                        }
                    } else when (e.type) {
                        1 -> for (i in -1..1) { val a = base + i * 0.15f; bullets.add(B(e.x, e.y + 7f, cos(a) * speed, sin(a) * speed, false)) }
                        3 -> for (i in -1..1) { val a = base + i * 0.23f; bullets.add(B(e.x, e.y + 7f, cos(a) * speed * 1.1f, sin(a) * speed * 1.1f, false)) }
                        4 -> for (i in -2..2) { val a = base + i * 0.12f; bullets.add(B(e.x, e.y + 7f, cos(a) * speed * 0.88f, sin(a) * speed * 0.88f, false)) }
                        6 -> for (i in -2..2) { val a = base + i * 0.24f; bullets.add(B(e.x, e.y + 7f, cos(a) * speed * 1.25f, sin(a) * speed * 1.25f, false)) }
                        else -> for (i in -1..1) { val a = base + i * 0.12f; bullets.add(B(e.x, e.y + 7f, cos(a) * speed, sin(a) * speed, false)) }
                    }''', 'wave 10+ varied adaptive attacks')
rep('''                    e.fire = when (e.type) {
                        1 -> max(0.48f, 1.12f - wave * 0.012f)
                        3 -> max(0.58f, 1.36f - wave * 0.013f)
                        4 -> max(0.72f, 1.62f - wave * 0.011f)
                        6 -> max(0.44f, 0.92f - wave * 0.009f)
                        else -> max(0.82f, 1.82f - wave * 0.010f)
                    }''', '''                    val baseInterval = when (e.type) {
                        1 -> max(0.48f, 1.12f - wave * 0.012f)
                        3 -> max(0.58f, 1.36f - wave * 0.013f)
                        4 -> max(0.72f, 1.62f - wave * 0.011f)
                        6 -> max(0.44f, 0.92f - wave * 0.009f)
                        else -> max(0.82f, 1.82f - wave * 0.010f)
                    }
                    e.fire = baseInterval * if (wave >= 10) 0.80f else 1f''', 'wave 10+ enemy firing cadence')

# Gold instead of purple/pink: give gravitational wells a warm metallic identity.
rep('''        paint.color = 0xFF8C63FF.toInt()
        c.drawCircle(cx, cy, r * (0.68f + 0.035f * sin(hole.spin)), paint)
        paint.strokeWidth = 0.7f * s
        paint.color = 0xFF35D9F2.toInt()
        c.drawCircle(cx, cy, r * (0.84f + 0.025f * cos(hole.spin * 1.3f)), paint)''', '''        paint.color = 0xFFFFC247.toInt()
        c.drawCircle(cx, cy, r * (0.68f + 0.035f * sin(hole.spin)), paint)
        paint.strokeWidth = 0.7f * s
        paint.color = 0xFFFFE6A6.toInt()
        c.drawCircle(cx, cy, r * (0.84f + 0.025f * cos(hole.spin * 1.3f)), paint)''', 'gold black hole rings')
rep('paint.color = 0xFFFF75D8.toInt()', 'paint.color = 0xFFFFD166.toInt()', 'gold black hole arc')
rep('paint.color = 0xFFB59BFF.toInt()', 'paint.color = 0xFFD89425.toInt()', 'gold black hole core rim')
rep('''            paint.color = when (i) { 0 -> 0xFFD8C5FF.toInt(); 1 -> 0xFF8C63FF.toInt(); 2 -> 0xFF35D9F2.toInt(); else -> 0x667C6CFF }
            paint.strokeWidth = (2.2f - i * 0.32f) * s''', '''            paint.color = when (i) { 0 -> 0xFFFFE7A3.toInt(); 1 -> 0xFFFFC247.toInt(); 2 -> 0xFFD89425.toInt(); else -> 0x66FFD166 }
            paint.strokeWidth = (2.2f - i * 0.32f) * s''', 'gold black hole orbit')
rep('paint.color = if (i % 3 == 0) 0xFFE7D9FF.toInt() else 0xFF8F77FF.toInt()', 'paint.color = if (i % 3 == 0) 0xFFFFF0C2.toInt() else 0xFFFFB52E.toInt()', 'gold black hole particles')

# Persianise ships, combo labels, events, ability names/descriptions and all user-facing UI.
replacements = {
    '"VIPER"':'"افعی"', '"TITAN"':'"تایتان"', '"PHANTOM"':'"شبح"', '"STRIKER"':'"مهاجم"',
    '"OVERDRIVE"':'"فراشتاب"', '"AFTERBURN"':'"پس‌سوز"', '"AEGIS"':'"ایجیس"', '"STEALTH"':'"مخفی‌کاری"',
    '"MISSILE DRONES"':'"پهپاد موشکی"', '"PRISM LASER"':'"لیزر منشوری"', '"MAGNETIC AEGIS"':'"سپر مغناطیسی"',
    '"METEOR SHOWER"':'"بارش شهاب‌سنگ"', '"BLACK HOLE SURGE"':'"خیزش سیاه‌چاله"', '"CHAIN REACTION"':'"واکنش زنجیره‌ای"', '"GOLDEN CRATE"':'"جعبه طلایی"', '"HUNTER SQUAD"':'"گروه شکارچی"',
    '"EXTRA LIFE ACTIVATED"':'"جان اضافه فعال شد"', '"AD NOT COMPLETED"':'"تبلیغ کامل نشد"',
    '"PLAY"':'"شروع بازی"', '"SOUND: ON"':'"صدا: روشن"', '"SOUND: OFF"':'"صدا: خاموش"', '"SHIP: "':'"سفینه: "',
    '"WAIT FOR AD..."':'"در انتظار تبلیغ..."', '"EXTRA LIFE  /  WATCH AD"':'"جان اضافه | تماشای تبلیغ"',
    '"RETRY"':'"تلاش دوباره"', '"MENU"':'"منو"', '"TAKE"':'"انتخاب"',
    '"WEAPON 320"':'"سلاح | ۳۲۰ سکه"', '"SHIELD 260"':'"سپر | ۲۶۰ سکه"', '"DASH 220"':'"جهش | ۲۲۰ سکه"', '"CONTINUE"':'"ادامه"',
    '"ACTIVE"':'"فعال"', '"CD "':'"آماده‌سازی "',
    '"SCORE $score"':'"امتیاز $score"', '"COMBO x"':'"ترکیب x"', '"SH"':'"سپر"', '"DASH "':'"جهش "', '"PHASE "':'"فاز "',
    '"BOSS"':'"باس"', '"!! BOSS !!"':'"!! باس !!"', '"WAVE $wave"':'"مرحله $wave"',
    '"CHOOSE ONE  •  "':'"یکی را انتخاب کن • "', '" UNLOCKED"':'" بازشده"', '"/5 SLOTS"':'"/۵ جایگاه"',
    '"NEW ABILITIES UNLOCKED"':'"توانایی‌های تازه باز شدند"', '"MAX FIVE ABILITIES UNTIL LEVEL 50"':'"تا مرحله ۵۰ حداکثر ۵ توانایی"',
    '"BETWEEN-WAVE HANGAR"':'"آشیانه بین مراحل"', '"CREDITS "':'"سکه: "',
    '"SHIP "':'"سفینه: "', '"   CREDITS "':'"   سکه: "',
    '"DAILY COMPLETE +500"':'"ماموریت روزانه کامل شد: +۵۰۰"', '"DAILY 25 KILLS "':'"ماموریت روزانه: ۲۵ نابودی "',
    '"BEST $best  WAVE $bestWave"':'"بهترین امتیاز: $best   رکورد مرحله: $bestWave"',
    '"SCORE $score"':'"امتیاز $score"', '"NEW BEST!"':'"رکورد جدید!"', '"BEST $best"':'"بهترین: $best"',
    '"WAVE COMPLETE"':'"مرحله کامل شد"', '"PREPARING NEXT WAVE"':'"آماده‌سازی مرحله بعد"',
    '"RAPID "':'"شلیک سریع "', '"REFLECT "':'"سپر بازتابی "', '"EMP PULSE "':'"موج الکترومغناطیسی "',
    '"MISSILE"':'"موشک"', '"LASER"':'"لیزر"',
}
for old, new in replacements.items():
    g = g.replace(old, new)

# Upgrade cards: each title and the complete explanation is Persian.
title_map = {
    'FIREPOWER':'قدرت آتش','MISSILES':'موشک‌ها','LASER':'لیزر','DRONES':'پهپادها','MAGNET':'آهنربا',
    'REFLECT SHIELD':'سپر بازتابی','EMERGENCY DASH':'جهش اضطراری','CHAIN LIGHTNING':'صاعقه زنجیره‌ای','HULL +1':'جان +۱',
    'HEALTH REGEN':'بازیابی جان','EMP PULSE':'موج الکترومغناطیسی','RICOCHET':'گلوله کمانه‌ای','GRAVITY WELL':'چاه گرانشی',
    'OVERLOAD':'اضافه‌بار سلاح','NANOBOTS':'نانوماشین‌ها','WEAK POINT SCANNER':'ردیاب نقطه ضعف','SALVAGE DRONE':'پهپاد جمع‌آوری',
    'KILL STREAK':'زنجیره نابودی','RICOCHET SHIELD':'سپر کمانه‌ای','NANO ARMOR':'زره نانو','CRITICAL HIT':'ضربه حیاتی',
    'OVERDRIVE':'فراشتاب','EXPLOSIVE SHOTS':'گلوله انفجاری','PIERCING ROUNDS':'گلوله نفوذی','STASIS FIELD':'میدان سکون',
    'SCAVENGER':'غارتگر','MULTI SHOT':'شلیک چندگانه','PHOENIX CORE':'هسته ققنوس','RAPID FIRE':'شلیک سریع'
}
info_map = {
    '+DAMAGE +FIRE RATE':'آسیب و سرعت شلیک بیشتر','MORE HOMING ROCKETS':'موشک‌های هدف‌گیر بیشتر','STRONGER LASER':'لیزر قدرتمندتر',
    'ORBIT + INTERCEPT':'چرخش و رهگیری گلوله‌ها','PASSIVE ITEM PULL':'جذب خودکار آیتم‌ها','REFLECT ENEMY SHOTS':'بازتاب گلوله‌های دشمن',
    'ONE SAFE TELEPORT':'یک جهش ایمن در میدان','ARC TO NEARBY ENEMY':'انتقال صاعقه به دشمن نزدیک','RESTORE ONE LIFE':'افزایش یک واحد جان',
    'REPAIR HULL OVER TIME':'ترمیم تدریجی بدنه سفینه','PULSE DAMAGES ALL ENEMIES':'آسیب موجی به همه دشمن‌ها','BULLETS BOUNCE TO NEW TARGETS':'گلوله‌ها به هدف تازه کمانه می‌کنند',
    'PULL AND DAMAGE NEARBY ENEMIES':'کشیدن و آسیب به دشمنان نزدیک','TEMPORARY HIGH-DAMAGE WEAPON OVERLOAD':'افزایش موقت آسیب سلاح',
    'REPAIR HULL AND SHIELD OVER TIME':'ترمیم تدریجی جان و سپر','MARK TARGETS FOR BONUS DAMAGE':'نشانه‌گذاری برای آسیب بیشتر',
    'DRONE COLLECTS EXTRA CREDITS':'پهپاد سکه بیشتری جمع می‌کند','CHAINED KILLS GRANT BONUS SCORE':'نابودی پیاپی امتیاز اضافه می‌دهد',
    'CHANCE TO REFLECT INCOMING DAMAGE':'احتمال بازتاب ضربه ورودی','CHANCE TO IGNORE A HIT':'احتمال خنثی‌کردن ضربه',
    'CHANCE FOR BONUS DAMAGE':'احتمال واردکردن آسیب اضافه','PERMANENT FIRE RATE BOOST':'افزایش دائمی سرعت شلیک',
    'DAMAGE NEARBY ENEMIES':'آسیب به دشمنان اطراف','BULLETS PIERCE MORE TARGETS':'عبور گلوله از چند هدف',
    'SLOW ALL ENEMIES':'کندکردن همه دشمن‌ها','MORE CREDITS PER KILL':'سکه بیشتر با هر نابودی',
    'ADD SIDE-FIRING LANES':'افزودن مسیرهای شلیک جانبی','ONE AUTOMATIC REVIVE':'یک بار احیای خودکار','TEMPORARY FAST SHOTS':'شلیک سریع برای مدت محدود'
}
for old, new in {**title_map, **info_map}.items():
    g = g.replace(f'"{old}"', f'"{new}"')

# Remaining HUD labels and dynamically composed values.
g = g.replace('"غول " + (bs.t0.toInt() + 1) + "/10  PHASE " + bs.phase', '"غول " + (bs.t0.toInt() + 1) + "/۱۰  فاز " + bs.phase')
g = g.replace('"ماموریت روزانه: ۲۵ نابودی " + dailyKills + "/25"', '"ماموریت روزانه: ۲۵ نابودی " + dailyKills + "/۲۵"')
g = g.replace('"s"', '"ثانیه"')

# Small remaining HUD strings and legendary labels that are dynamically composed.
g = g.replace('"  PHASE "', '"  فاز "')
g = g.replace('"BOSS "', '"باس "')
g = g.replace('"ACTIVE"', '"فعال"').replace('"CD "', '"آماده‌سازی "')
g = g.replace('"2x"', '"۲×"')
g = g.replace('"/5"', '"/۵"')

# Fix small labels that should not be left in English.
for old, new in {
    '"NEON"':'"نئون"', '"SHOOTER"':'"شوتر"',
    '"جان"':'"جان"', '"SCORE"':'"امتیاز"',
}.items():
    g = g.replace(old, new)

GAME.write_text(g, encoding='utf-8')

# Request 90 Hz from Android; actual refresh remains limited by the panel's capabilities.
a = ACTIVITY.read_text(encoding='utf-8')
a = a.replace('''        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {''', '''        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestHighRefreshRate()
        if (Build.VERSION.SDK_INT >= 28) {''')
a = a.replace('''    override fun onResume() {
        super.onResume()
        hideBars()
    }''', '''    override fun onResume() {
        super.onResume()
        requestHighRefreshRate()
        hideBars()
    }

    @Suppress("DEPRECATION")
    private fun requestHighRefreshRate() {
        if (Build.VERSION.SDK_INT >= 23) {
            val params = window.attributes
            params.preferredRefreshRate = 90f
            window.attributes = params
        }
    }''')
ACTIVITY.write_text(a, encoding='utf-8')

# Version bump. Keep Tapsell Plus dependency and signing unchanged.
gr = GRADLE.read_text(encoding='utf-8').replace('versionCode = 15', 'versionCode = 16').replace('versionName = "2.1.1"', 'versionName = "2.2.0"')
GRADLE.write_text(gr, encoding='utf-8')
strings = STRINGS.read_text(encoding='utf-8').replace('<string name="app_name">Neon Shooter</string>', '<string name="app_name">شوتر نئونی</string>')
STRINGS.write_text(strings, encoding='utf-8')
print('Neon Shooter 2.2.0 patch applied.')
