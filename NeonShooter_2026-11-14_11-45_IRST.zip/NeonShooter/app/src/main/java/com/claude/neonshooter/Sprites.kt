package com.claude.neonshooter

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint

/** Pixel-art sprites: '#' = main color, 'w' = white, '.' = empty. Each gets a neon glow. */
object Sprites {
    val PLAYER = listOf("....#....", "...###...", "...#w#...", "..#####..", ".#######.", "###.#.###", "#...#...#")
    val ENEMY = listOf("#......#", ".#....#.", ".######.", "##.##.##", "########", "#.####.#", "#.#..#.#", "...##...")
    val ENEMY2 = listOf("..#...#..", "#.#####.#", "#########", "##.###.##", "#########", ".#######.", "..#...#..", ".##...##.")
    private val BOSS_HALF = listOf("..#.....##", ".###..####", "##########", "##.###w###", "##########", ".###.#####", "..##..#.##", "...#....##")
    val BOSS = BOSS_HALF.map { it + it.reversed().substring(1) }
    val PBULLET = listOf("#", "#", "#")
    val EBULLET = listOf("##", "##")

    fun build(rows: List<String>, color: Int, glow: Int, ps: Int): Bitmap {
        val w = rows[0].length * ps
        val h = rows.size * ps
        val base = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(base)
        val p = Paint()
        for ((y, r) in rows.withIndex()) for ((x, ch) in r.withIndex()) {
            if (ch == '.') continue
            p.color = if (ch == 'w') Color.WHITE else color
            c.drawRect((x * ps).toFloat(), (y * ps).toFloat(), ((x + 1) * ps).toFloat(), ((y + 1) * ps).toFloat(), p)
        }
        val g = ps * 2
        val out = Bitmap.createBitmap(w + 2 * g, h + 2 * g, Bitmap.Config.ARGB_8888)
        val oc = Canvas(out)
        val bp = Paint().apply { maskFilter = BlurMaskFilter(g.toFloat(), BlurMaskFilter.Blur.NORMAL) }
        val off = IntArray(2)
        val a = base.extractAlpha(bp, off)
        val gp = Paint().apply { this.color = glow }
        oc.drawBitmap(a, (g + off[0]).toFloat(), (g + off[1]).toFloat(), gp)
        oc.drawBitmap(a, (g + off[0]).toFloat(), (g + off[1]).toFloat(), gp)
        oc.drawBitmap(base, g.toFloat(), g.toFloat(), null)
        return out
    }
}
