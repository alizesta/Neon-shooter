package com.claude.neonshooter

import android.app.Activity
import android.graphics.*
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.*
import kotlin.random.Random

class GameView(private val act: Activity) : SurfaceView(act), SurfaceHolder.Callback, Runnable {

    private enum class St { MENU, PLAY, OVER }
    private class B(var x: Float, var y: Float, val vx: Float, val vy: Float, val mine: Boolean)
    private class E(var x: Float, var y: Float, val type: Int, var hp: Int, val bx: Float, val amp: Float, val t0: Float) {
        val maxHp = hp
        var age = 0f
        var dead = false
        var fire = Random.nextFloat() * 2f + 1f
        val hw = if (type == 2) 19f else if (type == 1) 9f else 8f
        val hh = 8f
    }
    private class Pt(var x: Float, var y: Float, val vx: Float, val vy: Float, var life: Float, val max: Float)
    private class Btn(val id: String, val label: String, val r: RectF)
    private class Star(var x: Float, val y0: Float, val sp: Float, val sz: Float) { var y = y0 }

    // palette: gray / yellow / red / white (+ orange warning)
    private val BG = 0xFF2A2A2E.toInt(); private val STAR = 0xFF4A4A52.toInt()
    private val YEL = 0xFFFFD400.toInt(); private val YGL = 0xFFFFEB66.toInt()
    private val RED = 0xFFFF3B3B.toInt(); private val RGL = 0xFFFF8080.toInt()
    private val DRED = 0xFFC4001D.toInt(); private val ORG = 0xFFFF8C00.toInt()
    private val WHT = 0xFFFFFFFF.toInt(); private val WGL = 0xFFE0E0FF.toInt()

    private val lock = Any()
    private var thread: Thread? = null
    @Volatile private var running = false
    private val W = 180f
    private var sw = 0; private var sh = 0; private var s = 1f; private var wh = 320f
    private var st = St.MENU
    private val sfx = Sfx(act)
    private val prefs = act.getSharedPreferences("neon", 0)
    private var best = prefs.getInt("best", 0)

    private val bullets = ArrayList<B>(); private val enemies = ArrayList<E>()
    private val parts = ArrayList<Pt>(); private val stars = ArrayList<Star>()
    private var px = 90f; private var py = 270f
    private var lives = 3; private var score = 0; private var wave = 0
    private var invul = 0f; private var fireT = 0f; private var time = 0f
    private var waiting = false; private var waveT = 0f; private var bannerT = 0f; private var overT = 0f
    private var kills = 0
    private val unlocked = HashSet<Int>()
    private var lx = 0f; private var ly = 0f

    private lateinit var bPlayer: Bitmap; private lateinit var bMini: Bitmap
    private lateinit var bE0: Bitmap; private lateinit var bE1: Bitmap; private lateinit var bBoss: Bitmap
    private lateinit var bPB: Bitmap; private lateinit var bEB: Bitmap

    private val paint = Paint()
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) }

    init { holder.addCallback(this) }

    // ---------- surface / thread ----------
    override fun surfaceCreated(h: SurfaceHolder) {}
    override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {
        synchronized(lock) { if (w != sw || hh != sh || !::bPlayer.isInitialized) setup(w, hh) }
        if (thread == null) { running = true; thread = Thread(this).also { it.start() } }
    }
    override fun surfaceDestroyed(h: SurfaceHolder) {
        running = false
        try { thread?.join() } catch (e: InterruptedException) {}
        thread = null
    }

    private fun setup(w: Int, h: Int) {
        sw = w; sh = h; s = w / W; wh = h / s
        val ps = max(2, (s * 2).roundToInt())
        bPlayer = Sprites.build(Sprites.PLAYER, YEL, YGL, ps)
        bMini = Sprites.build(Sprites.PLAYER, YEL, YGL, max(1, ps / 2))
        bE0 = Sprites.build(Sprites.ENEMY, RED, RGL, ps)
        bE1 = Sprites.build(Sprites.ENEMY2, DRED, RED, ps)
        bBoss = Sprites.build(Sprites.BOSS, DRED, RED, ps)
        bPB = Sprites.build(Sprites.PBULLET, WHT, WGL, ps)
        bEB = Sprites.build(Sprites.EBULLET, ORG, ORG, ps)
        if (stars.isEmpty()) repeat(60) {
            val l = Random.nextInt(3)
            stars.add(Star(Random.nextFloat() * W, Random.nextFloat() * wh, floatArrayOf(8f, 16f, 28f)[l], if (l == 2) 1.6f else 1f))
        }
        if (st != St.PLAY) { px = W / 2; py = wh - 45f }
    }

    override fun run() {
        var last = System.nanoTime()
        while (running) {
            val now = System.nanoTime()
            val dt = min(0.033f, (now - last) / 1e9f); last = now
            synchronized(lock) { update(dt) }
            var c: Canvas? = null
            try {
                c = holder.lockCanvas()
                if (c != null) synchronized(lock) { draw(c) }
            } catch (e: Exception) {
            } finally {
                if (c != null) try { holder.unlockCanvasAndPost(c) } catch (e: Exception) {}
            }
            try { Thread.sleep(6) } catch (e: InterruptedException) {}
        }
    }

    // ---------- input ----------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        synchronized(lock) {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lx = e.x; ly = e.y
                    if (st != St.PLAY && !(st == St.OVER && overT < 0.7f)) {
                        buttons().firstOrNull { it.r.contains(e.x / s, e.y / s) }?.let { onBtn(it.id) }
                    }
                }
                MotionEvent.ACTION_MOVE -> if (st == St.PLAY) {
                    px = (px + (e.x - lx) / s).coerceIn(10f, W - 10f)
                    py = (py + (e.y - ly) / s).coerceIn(30f, wh - 14f)
                    lx = e.x; ly = e.y
                }
            }
        }
        return true
    }

    private fun onBtn(id: String) {
        when (id) {
            "play" -> startGame()
            "menu" -> st = St.MENU
            "lb" -> Play.showLeaderboard(act)
            "ach" -> Play.showAchievements(act)
            "signin" -> Play.signIn(act)
            "sound" -> sfx.enabled = !sfx.enabled
        }
    }

    private fun buttons(): List<Btn> {
        val l = ArrayList<Btn>()
        fun add(id: String, label: String, y: Float) { l.add(Btn(id, label, RectF(30f, y, 150f, y + 22f))) }
        when (st) {
            St.MENU -> {
                val y = wh * 0.45f
                add("play", "PLAY", y)
                add("lb", "LEADERBOARD", y + 30f)
                add("ach", "ACHIEVEMENTS", y + 60f)
                add("signin", if (Play.signedIn) "GOOGLE: ONLINE" else "GOOGLE SIGN-IN", y + 90f)
                add("sound", if (sfx.enabled) "SOUND: ON" else "SOUND: OFF", y + 120f)
            }
            St.OVER -> { val y = wh * 0.58f; add("play", "RETRY", y); add("menu", "MENU", y + 30f) }
            else -> {}
        }
        return l
    }

    // ---------- game logic ----------
    private fun startGame() {
        bullets.clear(); enemies.clear(); parts.clear()
        score = 0; lives = 3; wave = 0; kills = 0; invul = 1.5f; fireT = 0f; time = 0f
        px = W / 2; py = wh - 45f; waiting = true; waveT = 0.6f
        st = St.PLAY
        sfx.play("start")
    }

    private fun ach(resId: Int) { if (unlocked.add(resId)) Play.unlock(act, resId) }

    private fun spawnWave() {
        wave++
        bannerT = 1.6f
        if (wave >= 10) ach(R.string.achievement_wave_10)
        if (wave % 5 == 0) {
            enemies.add(E(W / 2, -20f, 2, 30 + wave * 6, W / 2, 0f, 0f).also { it.fire = 1.5f })
            return
        }
        val n = min(5 + wave / 2, 10)
        fun mk(x: Float, y: Float, amp: Float, t0: Float) {
            val strong = wave >= 3 && Random.nextFloat() < 0.3f
            enemies.add(E(x, y, if (strong) 1 else 0, if (strong) 3 else 1, x, amp, t0))
        }
        when (wave % 3) {
            0 -> for (i in 0 until n) mk((i + 0.5f) * W / n, -10f - (i % 2) * 14f, 0f, 0f)
            1 -> for (i in 0 until n) mk(W / 2, -10f - i * 24f, 55f, i * 0.6f)
            else -> for (i in 0 until n) {
                val side = if (i % 2 == 0) 1 else -1; val k = (i + 1) / 2
                mk(W / 2 + side * k * 20f, -10f - k * 14f, 0f, 0f)
            }
        }
    }

    private fun boom(x: Float, y: Float, n: Int, sp: Float = 60f) {
        repeat(n) {
            val a = Random.nextFloat() * 6.283f; val v = Random.nextFloat() * sp + 10f
            parts.add(Pt(x, y, cos(a) * v, sin(a) * v, 0.6f, 0.6f))
        }
    }

    private fun kill(e: E) {
        e.dead = true
        when (e.type) { 0 -> score += 10; 1 -> score += 30; else -> score += 500 }
        boom(e.x, e.y, if (e.type == 2) 70 else 16, if (e.type == 2) 90f else 55f)
        sfx.play(if (e.type == 2) "bigboom" else "boom")
        kills++
        if (kills == 1) ach(R.string.achievement_first_kill)
        if (score >= 1000) ach(R.string.achievement_score_1000)
        if (e.type == 2) { ach(R.string.achievement_boss_slayer); bullets.removeAll { !it.mine } }
    }

    private fun hurt() {
        lives--
        invul = 1.8f
        boom(px, py, 24, 70f)
        sfx.play("hurt")
        if (lives <= 0) {
            st = St.OVER; overT = 0f
            sfx.play("over")
            if (score > best) { best = score; prefs.edit().putInt("best", best).apply() }
            Play.submit(act, score)
        }
    }

    private fun shoot() {
        val lvl = min(1 + wave / 4, 3)
        when (lvl) {
            1 -> bullets.add(B(px, py - 9f, 0f, -170f, true))
            2 -> { bullets.add(B(px - 4f, py - 9f, 0f, -170f, true)); bullets.add(B(px + 4f, py - 9f, 0f, -170f, true)) }
            else -> {
                bullets.add(B(px, py - 9f, 0f, -170f, true))
                bullets.add(B(px - 5f, py - 6f, -22f, -165f, true)); bullets.add(B(px + 5f, py - 6f, 22f, -165f, true))
            }
        }
        sfx.play("shoot")
    }

    private fun update(dt: Float) {
        for (star in stars) { star.y += star.sp * dt; if (star.y > wh) { star.y = 0f; star.x = Random.nextFloat() * W } }
        for (p in parts) { p.x += p.vx * dt; p.y += p.vy * dt; p.life -= dt }
        parts.removeAll { it.life <= 0f }
        if (st == St.OVER) overT += dt
        if (st != St.PLAY) return

        time += dt; invul -= dt; fireT -= dt; bannerT -= dt
        if (fireT <= 0f) { fireT = 0.17f; shoot() }

        // waves
        if (enemies.isEmpty()) {
            if (!waiting) { waiting = true; waveT = 1.0f }
            else { waveT -= dt; if (waveT <= 0f) { spawnWave(); waiting = false } }
        }

        // enemies
        val spd = min(22f + wave * 1.5f, 50f)
        for (e in enemies) {
            e.age += dt
            if (e.type == 2) {
                if (e.y < 32f) e.y += 30f * dt
                e.x = W / 2 + sin(e.age * 0.9f) * (W / 2 - e.hw - 6f)
            } else {
                e.y += spd * dt
                e.x = (e.bx + sin(e.age * 2.2f + e.t0) * e.amp).coerceIn(8f, W - 8f)
            }
            e.fire -= dt
            if (e.fire <= 0f) {
                if (e.type == 2) {
                    e.fire = max(0.7f, 1.3f - wave * 0.02f)
                    for (i in -2..2) {
                        val a = (PI / 2 + i * 0.3).toFloat()
                        bullets.add(B(e.x, e.y + 8f, cos(a) * 60f, sin(a) * 60f, false))
                    }
                } else {
                    e.fire = Random.nextFloat() * 2.5f + 2.5f - min(wave * 0.05f, 1.5f)
                    if (e.y > 4f && e.y < wh * 0.55f) {
                        if (e.type == 1) {
                            val dx = px - e.x; val dy = py - e.y; val d = max(1f, hypot(dx, dy))
                            bullets.add(B(e.x, e.y + 8f, dx / d * 75f, dy / d * 75f, false))
                        } else bullets.add(B(e.x, e.y + 8f, 0f, 70f, false))
                    }
                }
            }
        }
        enemies.removeAll { it.y > wh + 12f }

        // bullets
        for (b in bullets) { b.x += b.vx * dt; b.y += b.vy * dt }
        bullets.removeAll { it.y < -10f || it.y > wh + 10f || it.x < -10f || it.x > W + 10f }

        // player bullets vs enemies
        val deadB = HashSet<B>()
        for (b in bullets) {
            if (!b.mine) continue
            for (e in enemies) {
                if (e.dead || e.y < -4f) continue
                if (abs(b.x - e.x) < e.hw + 1.5f && abs(b.y - e.y) < e.hh + 3f) {
                    deadB.add(b); e.hp--; boom(b.x, b.y, 2, 25f)
                    if (e.hp <= 0) kill(e)
                    break
                }
            }
        }
        enemies.removeAll { it.dead }

        // player hit
        if (invul <= 0f) {
            var hit = false
            for (b in bullets) if (!b.mine && abs(b.x - px) < 5f && abs(b.y - py) < 5f) { deadB.add(b); hit = true; break }
            if (!hit) for (e in enemies) if (abs(e.x - px) < e.hw + 4f && abs(e.y - py) < e.hh + 4f) {
                if (e.type != 2) { e.dead = true; boom(e.x, e.y, 14) }
                hit = true; break
            }
            if (hit) hurt()
        }
        bullets.removeAll(deadB)
        enemies.removeAll { it.dead }
    }

    // ---------- drawing ----------
    private fun spr(c: Canvas, b: Bitmap, x: Float, y: Float) {
        c.drawBitmap(b, x * s - b.width / 2f, y * s - b.height / 2f, null)
    }

    private fun text(c: Canvas, t: String, x: Float, y: Float, size: Float, color: Int, align: Paint.Align = Paint.Align.CENTER) {
        tp.textSize = size * s; tp.color = color; tp.textAlign = align
        tp.setShadowLayer(7f, 0f, 0f, color)
        c.drawText(t, x * s, y * s, tp)
    }

    private fun draw(c: Canvas) {
        if (!::bPlayer.isInitialized) return
        c.drawColor(BG)
        paint.style = Paint.Style.FILL
        for (star in stars) {
            paint.color = STAR
            c.drawRect(star.x * s, star.y * s, (star.x + star.sz) * s, (star.y + star.sz) * s, paint)
        }
        when (st) {
            St.MENU -> drawMenu(c)
            St.PLAY -> drawGame(c)
            St.OVER -> { drawGame(c); drawOver(c) }
        }
    }

    private fun drawGame(c: Canvas) {
        for (e in enemies) spr(c, if (e.type == 2) bBoss else if (e.type == 1) bE1 else bE0, e.x, e.y)
        for (b in bullets) spr(c, if (b.mine) bPB else bEB, b.x, b.y)
        if (st == St.PLAY && (invul <= 0f || (time * 12).toInt() % 2 == 0)) spr(c, bPlayer, px, py)
        for (p in parts) {
            val k = 1f - p.life / p.max
            paint.color = if (k < 0.3f) WHT else if (k < 0.6f) YEL else RED
            paint.alpha = (255 * (p.life / p.max)).toInt().coerceIn(0, 255)
            c.drawRect(p.x * s, p.y * s, (p.x + 1.6f) * s, (p.y + 1.6f) * s, paint)
        }
        paint.alpha = 255
        text(c, "SCORE $score", 6f, 14f, 9f, YEL, Paint.Align.LEFT)
        for (i in 0 until lives) spr(c, bMini, W - 12f - i * 12f, 10f)
        enemies.firstOrNull { it.type == 2 }?.let { bs ->
            val frac = bs.hp.toFloat() / bs.maxHp
            paint.color = DRED; c.drawRect(20f * s, 20f * s, (20f + 140f * frac) * s, 23f * s, paint)
            paint.style = Paint.Style.STROKE; paint.strokeWidth = s * 0.6f; paint.color = RED
            c.drawRect(20f * s, 20f * s, 160f * s, 23f * s, paint); paint.style = Paint.Style.FILL
        }
        if (bannerT > 0f && st == St.PLAY) {
            val boss = wave % 5 == 0
            text(c, if (boss) "!! BOSS !!" else "WAVE $wave", W / 2, wh * 0.4f, 16f, if (boss) RED else WHT)
        }
    }

    private fun drawButtons(c: Canvas) {
        for (b in buttons()) {
            val col = if (b.id == "play") YEL else 0xFFCCCCCC.toInt()
            paint.style = Paint.Style.STROKE; paint.strokeWidth = s * 0.8f; paint.color = col
            paint.setShadowLayer(8f, 0f, 0f, col)
            c.drawRoundRect(b.r.left * s, b.r.top * s, b.r.right * s, b.r.bottom * s, 3f * s, 3f * s, paint)
            paint.clearShadowLayer(); paint.style = Paint.Style.FILL
            text(c, b.label, W / 2, b.r.top + 14.5f, 9f, col)
        }
    }

    private fun drawMenu(c: Canvas) {
        text(c, "NEON", W / 2, wh * 0.16f, 34f, YEL)
        text(c, "SHOOTER", W / 2, wh * 0.16f + 26f, 24f, RED)
        spr(c, bPlayer, W / 2, wh * 0.33f + sin(System.nanoTime() / 4e8f) * 3f)
        text(c, "BEST $best", W / 2, wh * 0.42f, 8f, WHT)
        drawButtons(c)
    }

    private fun drawOver(c: Canvas) {
        paint.color = 0xAA000000.toInt(); c.drawRect(0f, 0f, sw.toFloat(), sh.toFloat(), paint)
        text(c, "GAME OVER", W / 2, wh * 0.3f, 22f, RED)
        text(c, "SCORE $score", W / 2, wh * 0.3f + 20f, 11f, YEL)
        text(c, if (score >= best) "NEW BEST!" else "BEST $best", W / 2, wh * 0.3f + 34f, 8f, WHT)
        if (overT >= 0.7f) drawButtons(c)
    }
}
