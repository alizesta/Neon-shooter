#!/usr/bin/env python3
"""Apply Neon Shooter 2.1 Tapsell Mediation integration to a v2.0 Android project."""
from pathlib import Path
import os

ROOT = Path(os.environ.get("NEON_PROJECT_DIR", Path(__file__).resolve().parent / "NeonShooter"))
APP = ROOT / "app"
GAME = APP / "src/main/java/com/claude/neonshooter/GameView.kt"
GRADLE = APP / "build.gradle.kts"
SETTINGS = ROOT / "settings.gradle.kts"
README = ROOT / "README.md"


def replace_once(path: Path, old: str, new: str, label: str) -> None:
    data = path.read_text(encoding="utf-8")
    count = data.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected one match in {path}, found {count}")
    path.write_text(data.replace(old, new, 1), encoding="utf-8")


# Tapsell's official Android sample uses maven.tapsell.ir and SDK 1.4.0-alpha04.
settings_text = SETTINGS.read_text(encoding="utf-8")
if 'maven("https://maven.tapsell.ir")' not in settings_text:
    settings_text = settings_text.replace(
        "repositories { google(); mavenCentral() }",
        'repositories { google(); mavenCentral(); maven("https://maven.tapsell.ir") }',
        1,
    )
    SETTINGS.write_text(settings_text, encoding="utf-8")

# Read credentials from an ignored local file or CI environment, never from source.
gradle_text = GRADLE.read_text(encoding="utf-8")
if "TAPSELL_SECRET_KEY" not in gradle_text:
    gradle_text = gradle_text.replace(
        'plugins {\n    id("com.android.application")\n    id("org.jetbrains.kotlin.android")\n}\n',
        'import java.util.Properties\n\n'
        'plugins {\n'
        '    id("com.android.application")\n'
        '    id("org.jetbrains.kotlin.android")\n'
        '}\n\n'
        'val tapsellProperties = Properties().apply {\n'
        '    val secretFile = rootProject.file("tapsell.properties")\n'
        '    if (secretFile.exists()) secretFile.inputStream().use { load(it) }\n'
        '}\n'
        'val tapsellSecretKey = System.getenv("TAPSELL_SECRET_KEY")\n'
        '    ?: providers.gradleProperty("TAPSELL_SECRET_KEY").orNull\n'
        '    ?: tapsellProperties.getProperty("tapsell.secretKey")\n'
        '    ?: ""\n',
        1,
    )
    gradle_text = gradle_text.replace(
        '        targetSdk = 34\n',
        '        targetSdk = 34\n'
        '        // Tapsell Mediation accepts the publisher secret-key as APP_KEY in 1.4.0-alpha03+.\n'
        '        manifestPlaceholders["TapsellMediationAppKey"] = tapsellSecretKey\n',
        1,
    )
    gradle_text = gradle_text.replace(
        '        versionCode = 13\n        versionName = "2.0"',
        '        versionCode = 14\n        versionName = "2.1"',
        1,
    )
    gradle_text = gradle_text.replace(
        'dependencies {\n}\n',
        'dependencies {\n'
        '    implementation("ir.tapsell:tapsell:1.4.0-alpha04")\n'
        '    // Only the Tapsell Legacy adapter is enabled. No AdMob/Google ad adapter.\n'
        '    implementation("ir.tapsell.mediation.adapter:legacy:1.4.0-alpha04")\n'
        '    implementation("ir.tapsell.mediation.adapter:legacy-ima-extension:1.4.0-alpha04")\n'
        '    implementation("ir.tapsell.mediation.adapter:legacy-taproll:1.4.0-alpha04")\n'
        '}\n',
        1,
    )
    GRADLE.write_text(gradle_text, encoding="utf-8")

ads_path = APP / "src/main/java/com/claude/neonshooter/TapsellAds.kt"
ads_path.write_text('''package com.claude.neonshooter

import android.app.Activity
import android.util.Log
import ir.tapsell.mediation.Tapsell
import ir.tapsell.mediation.ad.AdStateListener
import ir.tapsell.mediation.ad.request.RequestResultListener
import ir.tapsell.mediation.ad.show.AdShowCompletionState

/** Tapsell adapter for the two placements registered for Neon Shooter. */
object TapsellAds {
    private const val TAG = "NeonShooterAds"
    const val EXTRA_LIFE_ZONE_ID = "6af8b6bb4f21b435f88681e4"
    const val BETWEEN_WAVES_ZONE_ID = "6af8b707aeabeb750feb8be9"

    private val lock = Any()
    @Volatile private var rewardedResponseId: String? = null
    @Volatile private var interstitialResponseId: String? = null
    private var rewardedLoading = false
    private var interstitialLoading = false

    val isRewardedReady: Boolean
        get() = !rewardedResponseId.isNullOrBlank()

    fun preloadAll() {
        preloadRewarded()
        preloadInterstitial()
    }

    fun preloadRewarded() {
        synchronized(lock) {
            if (rewardedLoading || !rewardedResponseId.isNullOrBlank()) return
            rewardedLoading = true
        }
        try {
            Tapsell.requestRewardedAd(EXTRA_LIFE_ZONE_ID, object : RequestResultListener {
                override fun onFailure(message: String) {
                    synchronized(lock) { rewardedLoading = false; rewardedResponseId = null }
                    Log.w(TAG, "Rewarded request failed: $message")
                }

                override fun onSuccess(adId: String) {
                    synchronized(lock) { rewardedLoading = false; rewardedResponseId = adId }
                    Log.d(TAG, "Rewarded ad ready")
                }
            })
        } catch (error: Throwable) {
            synchronized(lock) { rewardedLoading = false; rewardedResponseId = null }
            Log.e(TAG, "Rewarded request error", error)
        }
    }

    fun preloadInterstitial() {
        synchronized(lock) {
            if (interstitialLoading || !interstitialResponseId.isNullOrBlank()) return
            interstitialLoading = true
        }
        try {
            Tapsell.requestInterstitialAd(BETWEEN_WAVES_ZONE_ID, object : RequestResultListener {
                override fun onFailure(message: String) {
                    synchronized(lock) { interstitialLoading = false; interstitialResponseId = null }
                    Log.w(TAG, "Interstitial request failed: $message")
                }

                override fun onSuccess(adId: String) {
                    synchronized(lock) { interstitialLoading = false; interstitialResponseId = adId }
                    Log.d(TAG, "Interstitial ad ready")
                }
            })
        } catch (error: Throwable) {
            synchronized(lock) { interstitialLoading = false; interstitialResponseId = null }
            Log.e(TAG, "Interstitial request error", error)
        }
    }

    /** Callback receives true only after the SDK's onRewarded callback, then the ad closes. */
    fun showRewarded(activity: Activity, onFinished: (Boolean) -> Unit) {
        val responseId = synchronized(lock) {
            rewardedResponseId.also { rewardedResponseId = null }
        }
        if (responseId.isNullOrBlank()) {
            preloadRewarded()
            onFinished(false)
            return
        }

        var rewardConfirmed = false
        var finished = false
        fun finish() {
            if (finished) return
            finished = true
            onFinished(rewardConfirmed)
            preloadRewarded()
        }

        try {
            Tapsell.showRewardedAd(responseId, activity, object : AdStateListener.Rewarded {
                override fun onAdClicked() = Unit
                override fun onAdClosed(completionState: AdShowCompletionState) = finish()
                override fun onAdFailed(message: String) {
                    Log.w(TAG, "Rewarded show failed: $message")
                    finish()
                }
                override fun onAdImpression() = Unit
                override fun onRewarded() { rewardConfirmed = true }
            })
        } catch (error: Throwable) {
            Log.e(TAG, "Rewarded show error", error)
            finish()
        }
    }

    /** Interstitials are requested ahead of time and shown only at wave transitions. */
    fun showInterstitial(activity: Activity, onFinished: () -> Unit) {
        val responseId = synchronized(lock) {
            interstitialResponseId.also { interstitialResponseId = null }
        }
        if (responseId.isNullOrBlank()) {
            preloadInterstitial()
            onFinished()
            return
        }

        var finished = false
        fun finish() {
            if (finished) return
            finished = true
            onFinished()
            preloadInterstitial()
        }

        try {
            Tapsell.showInterstitialAd(responseId, activity, object : AdStateListener.Interstitial {
                override fun onAdClicked() = Unit
                override fun onAdClosed(completionState: AdShowCompletionState) = finish()
                override fun onAdFailed(message: String) {
                    Log.w(TAG, "Interstitial show failed: $message")
                    finish()
                }
                override fun onAdImpression() = Unit
            })
        } catch (error: Throwable) {
            Log.e(TAG, "Interstitial show error", error)
            finish()
        }
    }
}
''', encoding="utf-8")

# Wire both placements into the v2.0 game loop and game-over screen.
replace_once(
    GAME,
    "private enum class St { MENU, PLAY, PAUSE, OVER, UPGRADE, SHOP }",
    "private enum class St { MENU, PLAY, PAUSE, OVER, UPGRADE, SHOP, AD_BREAK }",
    "add ad-break state",
)
replace_once(
    GAME,
    "private var intermissionHandledWave = -1\n",
    "private var intermissionHandledWave = -1\n"
    "    private var rewardedContinueUsed = false\n"
    "    private var rewardedContinuePending = false\n"
    "    private var interstitialShownThroughWave = -1\n"
    "    private var adStatusText = \"\"\n"
    "    private var adStatusTimer = 0f\n",
    "add ad state fields",
)
replace_once(
    GAME,
    "init { refreshDaily(); holder.addCallback(this) }",
    "init { refreshDaily(); holder.addCallback(this); TapsellAds.preloadAll() }",
    "preload ads when game view is created",
)
replace_once(
    GAME,
    '            "sound" -> sfx.enabled = !sfx.enabled\n',
    '            "sound" -> sfx.enabled = !sfx.enabled\n'
    '            "extraLife" -> {\n'
    '                if (st == St.OVER && !rewardedContinueUsed && !rewardedContinuePending) {\n'
    '                    rewardedContinuePending = true\n'
    '                    TapsellAds.showRewarded(act) { rewardConfirmed ->\n'
    '                        act.runOnUiThread {\n'
    '                            synchronized(lock) {\n'
    '                                rewardedContinuePending = false\n'
    '                                if (rewardConfirmed && st == St.OVER && !rewardedContinueUsed) {\n'
    '                                    rewardedContinueUsed = true\n'
    '                                    lives = 1\n'
    '                                    bullets.removeAll { !it.mine }\n'
    '                                    enemyLasers.clear()\n'
    '                                    invul = 3.0f\n'
    '                                    waiting = true\n'
    '                                    waveT = 1.1f\n'
    '                                    overT = 0f\n'
    '                                    st = St.PLAY\n'
    '                                    adStatusText = "EXTRA LIFE ACTIVATED"\n'
    '                                    adStatusTimer = 1.8f\n'
    '                                } else if (st == St.OVER) {\n'
    '                                    adStatusText = "AD NOT COMPLETED"\n'
    '                                    adStatusTimer = 1.8f\n'
    '                                }\n'
    '                            }\n'
    '                        }\n'
    '                    }\n'
    '                }\n'
    '            }\n',
    "wire rewarded button",
)
replace_once(
    GAME,
    '            St.OVER -> { val y = wh * 0.58f; add("play", "RETRY", y); add("menu", "MENU", y + 30f) }',
    '            St.OVER -> {\n'
    '                if (rewardedContinuePending) {\n'
    '                    add("extraLife", "WAIT FOR AD...", wh * 0.49f)\n'
    '                } else if (!rewardedContinueUsed) {\n'
    '                    val y = wh * 0.49f\n'
    '                    add("extraLife", "EXTRA LIFE  /  WATCH AD", y)\n'
    '                    add("play", "RETRY", y + 28f)\n'
    '                    add("menu", "MENU", y + 56f)\n'
    '                } else {\n'
    '                    val y = wh * 0.58f\n'
    '                    add("play", "RETRY", y)\n'
    '                    add("menu", "MENU", y + 30f)\n'
    '                }\n'
    '            }',
    "add extra-life button",
)
replace_once(
    GAME,
    '        st = St.PLAY\n        sfx.play("start")',
    '        rewardedContinueUsed = false\n'
    '        rewardedContinuePending = false\n'
    '        interstitialShownThroughWave = -1\n'
    '        adStatusText = ""; adStatusTimer = 0f\n'
    '        st = St.PLAY\n'
    '        TapsellAds.preloadAll()\n'
    '        sfx.play("start")',
    "reset ad state for each run",
)
replace_once(
    GAME,
    '        if (st == St.OVER) overT += dt\n',
    '        if (st == St.OVER) overT += dt\n'
    '        adStatusTimer = max(0f, adStatusTimer - dt)\n',
    "update ad status timer",
)
replace_once(
    GAME,
    '                if (waveT <= 0f) {\n'
    '                    if (wave > 0 && wave % 5 == 0 && shopHandledWave != wave) {',
    '                if (waveT <= 0f) {\n'
    '                    if (wave > 0 && wave % 5 == 0 && interstitialShownThroughWave < wave) {\n'
    '                        interstitialShownThroughWave = wave\n'
    '                        st = St.AD_BREAK\n'
    '                        act.runOnUiThread {\n'
    '                            TapsellAds.showInterstitial(act) {\n'
    '                                synchronized(lock) {\n'
    '                                    if (st == St.AD_BREAK) { st = St.PLAY; bannerT = max(bannerT, 0.55f) }\n'
    '                                }\n'
    '                            }\n'
    '                        }\n'
    '                        return\n'
    '                    }\n'
    '                    if (wave > 0 && wave % 5 == 0 && shopHandledWave != wave) {',
    "show interstitial only at five-wave intermissions",
)
replace_once(
    GAME,
    '            St.OVER -> { drawGame(c); drawOver(c) }\n'
    '            St.UPGRADE -> drawUpgrade(c)',
    '            St.OVER -> { drawGame(c); drawOver(c) }\n'
    '            St.AD_BREAK -> { drawGame(c); drawAdBreak(c) }\n'
    '            St.UPGRADE -> drawUpgrade(c)',
    "render intermission ad state",
)
replace_once(
    GAME,
    '        if (overT >= 0.7f) drawButtons(c)\n'
    '        drawAdSlot(c, wh * 0.84f)\n'
    '    }\n'
    '}',
    '        if (adStatusTimer > 0f) text(c, adStatusText, W / 2f, wh * 0.45f, 7f, 0xFFFFD45C.toInt())\n'
    '        if (overT >= 0.7f) drawButtons(c)\n'
    '        drawAdSlot(c, wh * 0.84f)\n'
    '    }\n\n'
    '    private fun drawAdBreak(c: Canvas) {\n'
    '        paint.style = Paint.Style.FILL\n'
    '        paint.color = 0xCC07111D.toInt()\n'
    '        c.drawRect(0f, 0f, sw.toFloat(), sh.toFloat(), paint)\n'
    '        drawGlassPanel(c, 25f, wh * 0.42f, 195f, wh * 0.58f, 0xFF47DFFF.toInt(), 230)\n'
    '        text(c, "WAVE COMPLETE", W / 2f, wh * 0.48f, 10f, 0xFF9CEBFF.toInt())\n'
    '        text(c, "PREPARING NEXT WAVE", W / 2f, wh * 0.53f, 6.5f, WHT)\n'
    '    }\n'
    '}',
    "draw ad status and intermission panel",
)

# Project-local setup; secret is excluded from Git and is added only to the delivered ZIP.
(ROOT / ".gitignore").write_text(
    "/.gradle/\n/build/\n/app/build/\n/local.properties\n/tapsell.properties\n/.idea/\n*.iml\n",
    encoding="utf-8",
)
( ROOT / "MONETIZATION_TAPSELL.md").write_text('''# Tapsell monetization — Neon Shooter 2.1

The project uses Tapsell Mediation Android SDK `1.4.0-alpha04` with the Tapsell Legacy adapter only. AdMob and Google ad adapters are not included.

## Credentials

The app reads the Tapsell publisher key from `tapsell.properties` in the project root:

```properties
tapsell.secretKey=YOUR_TAPSELL_PUBLISHER_KEY
```

The same value can be supplied as the `TAPSELL_SECRET_KEY` environment variable or Gradle property. Do not commit `tapsell.properties` to Git. SDK versions `1.4.0-alpha03` and later support the secret key as an alternative to the app ID for `APP_KEY`.

## Placements

- `Extra Life` is a rewarded video offered on Game Over. One extra life is granted only after the SDK calls `onRewarded` and the ad closes. It can be used once per run.
- `Between Waves` is an interstitial shown only after every fifth completed wave, before the existing shop/upgrade intermission. If no ad is ready, the game continues without blocking the player.

There are no permanent banners over the playfield. No Google Play Games, Google sign-in, AdMob adapter, or online leaderboard is added.
''', encoding="utf-8")

readme = README.read_text(encoding="utf-8")
readme = readme.replace("# Neon Shooter 2.0", "# Neon Shooter 2.1")
if "Tapsell" not in readme:
    readme += "\n## Ads\n- Optional rewarded Extra Life on Game Over.\n- Interstitial between waves at a five-wave interval.\n- Tapsell-only configuration; no AdMob or Google Play Games.\n- See `MONETIZATION_TAPSELL.md` for the local publisher-key setup.\n"
README.write_text(readme, encoding="utf-8")



APP_GRADLE_TEXT = 'android {\n    namespace = "com.claude.neonshooter"\n    compileSdk = 35\n    defaultConfig {\n        applicationId = "com.claude.neonshooter"\n        minSdk = 24\n        targetSdk = 34\n        versionCode = 15\n        versionName = "2.1.1"\n    }\n    signingConfigs {\n        create("release") {\n            val keyPath = System.getenv("NEON_KEYSTORE_PATH")\n            if (!keyPath.isNullOrBlank()) {\n                storeFile = file(keyPath)\n                storePassword = System.getenv("NEON_KEYSTORE_PASSWORD")\n                keyAlias = System.getenv("NEON_KEY_ALIAS")\n                keyPassword = System.getenv("NEON_KEY_PASSWORD")\n            }\n        }\n    }\n    buildTypes {\n        getByName("release") {\n            signingConfig = signingConfigs.getByName("release")\n            isMinifyEnabled = false\n        }\n    }\n    compileOptions {\n        sourceCompatibility = JavaVersion.VERSION_17\n        targetCompatibility = JavaVersion.VERSION_17\n    }\n    kotlinOptions { jvmTarget = "17" }\n}\ndependencies {\n    implementation("androidx.fragment:fragment-ktx:1.8.9")\n    // Native Tapsell Plus SDK matches the publisher app key and 24-character legacy zone IDs.\n    implementation("ir.tapsell.plus:tapsell-plus-sdk-android:2.3.3")\n}\n'
SETTINGS_TEXT = 'pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }\ndependencyResolutionManagement {\n    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)\n    repositories { google(); mavenCentral(); maven("https://maven.tapsell.ir") }\n}\nrootProject.name = "NeonShooter"\ninclude(":app")\n'
TAPSELL_PLUS_SOURCE = 'package com.claude.neonshooter\n\nimport android.util.Log\nimport androidx.fragment.app.FragmentActivity\nimport ir.tapsell.plus.AdRequestCallback\nimport ir.tapsell.plus.AdShowListener\nimport ir.tapsell.plus.TapsellPlus\nimport ir.tapsell.plus.TapsellPlusInitListener\nimport ir.tapsell.plus.model.AdNetworkError\nimport ir.tapsell.plus.model.AdNetworks\nimport ir.tapsell.plus.model.TapsellPlusAdModel\nimport ir.tapsell.plus.model.TapsellPlusErrorModel\n\n/** Native Tapsell Plus integration for the legacy dashboard app key and zone IDs. */\nobject TapsellAds {\n    private const val TAG = "NeonShooterAds"\n    private const val TAPSELL_APP_KEY = "lsctnjmabrkreniskdjjojnmlnhikjpeqbeljegffrkgcnlrkprmrfrnqlfislkqioibjo"\n    private const val EXTRA_LIFE_ZONE_ID = "6af8b6bb4f21b435f88681e4"\n    private const val BETWEEN_WAVES_ZONE_ID = "6af8b707aeabeb750feb8be9"\n\n    @Volatile private var initialized = false\n    @Volatile private var activity: FragmentActivity? = null\n    @Volatile private var rewardedResponseId: String? = null\n    @Volatile private var interstitialResponseId: String? = null\n    @Volatile private var rewardedLoading = false\n    @Volatile private var interstitialLoading = false\n\n    val isRewardedReady: Boolean\n        get() = !rewardedResponseId.isNullOrBlank()\n\n    fun initialize(host: FragmentActivity) {\n        activity = host\n        if (initialized) {\n            preloadAll()\n            return\n        }\n        try {\n            TapsellPlus.initialize(host, TAPSELL_APP_KEY, object : TapsellPlusInitListener {\n                override fun onInitializeSuccess(adNetworks: AdNetworks) {\n                    initialized = true\n                    TapsellPlus.setDebugMode(Log.DEBUG)\n                    Log.i(TAG, "Tapsell Plus initialized: $adNetworks")\n                    preloadAll()\n                }\n\n                override fun onInitializeFailed(adNetworks: AdNetworks, error: AdNetworkError) {\n                    initialized = false\n                    Log.e(TAG, "Tapsell Plus init failed ($adNetworks): ${error.errorMessage}")\n                }\n            })\n        } catch (error: Throwable) {\n            initialized = false\n            Log.e(TAG, "Tapsell Plus initialization error", error)\n        }\n    }\n\n    fun preloadAll() {\n        if (!initialized) return\n        preloadRewarded()\n        preloadInterstitial()\n    }\n\n    fun preloadRewarded() {\n        val host = activity ?: return\n        synchronized(this) {\n            if (!initialized || rewardedLoading || !rewardedResponseId.isNullOrBlank()) return\n            rewardedLoading = true\n        }\n        try {\n            TapsellPlus.requestRewardedVideoAd(host, EXTRA_LIFE_ZONE_ID, object : AdRequestCallback() {\n                override fun response(ad: TapsellPlusAdModel) {\n                    rewardedResponseId = ad.responseId\n                    rewardedLoading = false\n                    Log.i(TAG, "Rewarded ad ready")\n                }\n\n                override fun error(message: String) {\n                    rewardedLoading = false\n                    rewardedResponseId = null\n                    Log.e(TAG, "Rewarded request failed: $message")\n                }\n            })\n        } catch (error: Throwable) {\n            rewardedLoading = false\n            rewardedResponseId = null\n            Log.e(TAG, "Rewarded request exception", error)\n        }\n    }\n\n    fun preloadInterstitial() {\n        val host = activity ?: return\n        synchronized(this) {\n            if (!initialized || interstitialLoading || !interstitialResponseId.isNullOrBlank()) return\n            interstitialLoading = true\n        }\n        try {\n            TapsellPlus.requestInterstitialAd(host, BETWEEN_WAVES_ZONE_ID, object : AdRequestCallback() {\n                override fun response(ad: TapsellPlusAdModel) {\n                    interstitialResponseId = ad.responseId\n                    interstitialLoading = false\n                    Log.i(TAG, "Interstitial ad ready")\n                }\n\n                override fun error(message: String) {\n                    interstitialLoading = false\n                    interstitialResponseId = null\n                    Log.e(TAG, "Interstitial request failed: $message")\n                }\n            })\n        } catch (error: Throwable) {\n            interstitialLoading = false\n            interstitialResponseId = null\n            Log.e(TAG, "Interstitial request exception", error)\n        }\n    }\n\n    fun showRewarded(host: FragmentActivity, onFinished: (Boolean) -> Unit) {\n        activity = host\n        val responseId = rewardedResponseId.also { rewardedResponseId = null }\n        if (responseId.isNullOrBlank()) {\n            preloadRewarded()\n            onFinished(false)\n            return\n        }\n\n        var rewardConfirmed = false\n        var finished = false\n        fun finish() {\n            if (finished) return\n            finished = true\n            onFinished(rewardConfirmed)\n            preloadRewarded()\n        }\n\n        try {\n            TapsellPlus.showRewardedVideoAd(host, responseId, object : AdShowListener() {\n                override fun onOpened(ad: TapsellPlusAdModel) {\n                    Log.d(TAG, "Rewarded ad opened")\n                }\n\n                override fun onClosed(ad: TapsellPlusAdModel) {\n                    Log.d(TAG, "Rewarded ad closed")\n                    finish()\n                }\n\n                override fun onRewarded(ad: TapsellPlusAdModel) {\n                    rewardConfirmed = true\n                    Log.i(TAG, "Reward confirmed by Tapsell")\n                }\n\n                override fun onError(error: TapsellPlusErrorModel) {\n                    Log.e(TAG, "Rewarded show failed: $error")\n                    finish()\n                }\n            })\n        } catch (error: Throwable) {\n            Log.e(TAG, "Rewarded show exception", error)\n            finish()\n        }\n    }\n\n    fun showInterstitial(host: FragmentActivity, onFinished: () -> Unit) {\n        activity = host\n        val responseId = interstitialResponseId.also { interstitialResponseId = null }\n        if (responseId.isNullOrBlank()) {\n            preloadInterstitial()\n            onFinished()\n            return\n        }\n\n        var finished = false\n        fun finish() {\n            if (finished) return\n            finished = true\n            onFinished()\n            preloadInterstitial()\n        }\n\n        try {\n            TapsellPlus.showInterstitialAd(host, responseId, object : AdShowListener() {\n                override fun onOpened(ad: TapsellPlusAdModel) {\n                    Log.d(TAG, "Interstitial opened")\n                }\n\n                override fun onClosed(ad: TapsellPlusAdModel) {\n                    Log.d(TAG, "Interstitial closed")\n                    finish()\n                }\n\n                override fun onError(error: TapsellPlusErrorModel) {\n                    Log.e(TAG, "Interstitial show failed: $error")\n                    finish()\n                }\n            })\n        } catch (error: Throwable) {\n            Log.e(TAG, "Interstitial show exception", error)\n            finish()\n        }\n    }\n}\n'
MAIN_ACTIVITY_SOURCE = 'package com.claude.neonshooter\n\nimport androidx.fragment.app.FragmentActivity\nimport android.os.Build\nimport android.os.Bundle\nimport android.view.View\nimport android.view.WindowManager\n\nclass MainActivity : FragmentActivity() {\n    override fun onCreate(b: Bundle?) {\n        super.onCreate(b)\n        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)\n        if (Build.VERSION.SDK_INT >= 28) {\n            window.attributes.layoutInDisplayCutoutMode =\n                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES\n        }\n        TapsellAds.initialize(this)\n        setContentView(GameView(this))\n        hideBars()\n    }\n\n    override fun onResume() {\n        super.onResume()\n        hideBars()\n    }\n\n    override fun onWindowFocusChanged(hasFocus: Boolean) {\n        super.onWindowFocusChanged(hasFocus)\n        if (hasFocus) hideBars()\n    }\n\n    @Suppress("DEPRECATION")\n    private fun hideBars() {\n        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or\n            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or\n            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or\n            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION\n    }\n}\n'


APP_GRADLE_TEXT = 'plugins {\n    id("com.android.application")\n    id("org.jetbrains.kotlin.android")\n}\n' + APP_GRADLE_TEXT

# Finalize on Tapsell Plus 2.3.3 (not the earlier Tapsell Mediation API).
# Replace the app configuration as one complete, known-good project file.
(APP / "build.gradle.kts").write_text(APP_GRADLE_TEXT, encoding="utf-8")
SETTINGS.write_text(SETTINGS_TEXT, encoding="utf-8")
(APP / "src/main/java/com/claude/neonshooter/TapsellAds.kt").write_text(TAPSELL_PLUS_SOURCE, encoding="utf-8")
(APP / "src/main/java/com/claude/neonshooter/MainActivity.kt").write_text(MAIN_ACTIVITY_SOURCE, encoding="utf-8")

# GameView's host is Activity-typed; the app's real host is FragmentActivity.
game_text = GAME.read_text(encoding="utf-8")
for old, new, label in (
    ("TapsellAds.showRewarded(act) {", "TapsellAds.showRewarded(act as androidx.fragment.app.FragmentActivity) {", "rewarded host cast"),
    ("TapsellAds.showInterstitial(act) {", "TapsellAds.showInterstitial(act as androidx.fragment.app.FragmentActivity) {", "interstitial host cast"),
):
    count = game_text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected one match, found {count}")
    game_text = game_text.replace(old, new, 1)
GAME.write_text(game_text, encoding="utf-8")

(ROOT / "MONETIZATION_TAPSELL.md").write_text("""# Tapsell Plus monetization — Neon Shooter 2.1.1

Android SDK: `ir.tapsell.plus:tapsell-plus-sdk-android:2.3.3`.

- **Extra Life:** a rewarded video offered on Game Over. An extra life is granted only after Tapsell confirms the reward and the ad closes. One use per run.
- **Between Waves:** an interstitial shown at a natural pause after every fifth completed wave. It is never shown during active gameplay.
- Both placements are preloaded. If an ad is unavailable, gameplay continues without blocking.
- No AdMob, Google Play Games, Google sign-in, or permanent banner ads are included.

Ad placements are configured with the publisher app key and the two zone IDs from the Tapsell dashboard.
""", encoding="utf-8")
readme_text = README.read_text(encoding="utf-8").replace("# Neon Shooter 2.1", "# Neon Shooter 2.1.1")
README.write_text(readme_text, encoding="utf-8")
print("Neon Shooter 2.1.1 Tapsell Plus integration applied.")
